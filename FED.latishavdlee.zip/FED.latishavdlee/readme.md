# Procesverslag
**Auteur:** -Latisha van der Lee-

Markdown cheat cheet: [Hulp bij het schrijven van Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet). Nb. de standaardstructuur en de spartaanse opmaak zijn helemaal prima. Het gaat om de inhoud van je procesverslag. Besteedt de tijd voor pracht en praal aan je website.



## Bronnenlijst
1. https://www.awakenings.com/en/
2. https://www.w3schools.com/howto/howto_js_dropdown.asp
3. -...-


## Eindgesprek (herkansing in blok 2)

De lessen die ik in blok 1 heb gemist of niet helemaal heb begrepen heb ik in blok 2 nogmaals mogen volgen om toch nog het vak te kunnen halen. Helaas heb ik nog steeds niet het resultaat wat ik zou willen.

De content van mijn tweede pagina is niet responsible (dit wou ik met grid doen maar dat bleek ik minder goed te snappen dan ik in de les dacht) en ook werkt daar de achtergrond foto niet op waar van ik niet weet waarom.

Ook wou ik om de site responsible te maken de awakenings icoontjes van festival, merchandise en book op de webversie onder elkaar aan de zijkant van de pagina maar dit is me helaas ook niet gelukt.



## Eindgesprek (week 7/8)

Het resultaat is nog niet wat het moet zijn en ik ben er daarom ook vrij zeker van dat ik voor de herkansing moet gaan. Ik heb wel twee werkende pagina's maar de vormgeving is nog niet wat het moet zijn en ook is de pagina nog niet goed responsive.

Ik had redelijk wat problemen met mijn laptop afgelopen blok en heb in de herfstvakantie een nieuwe gekocht, maar omdat mijn oude niet alles meer deed heb ik een hoop opnieuw moeten maken in m'n code. Hierdoor had ik minder tijd problemen op te lossen en is het gewoon nog niet wat het moet zijn.

Ik merkte dat ik nogal moeite had om hulp te vragen wat er ook voor zorgde dat ik na een aantal weken een redelijke achterstand opliep. Dit was niet bepaald handig van mij en heeft er ook voor gezorgd dat mijn pagina's nu nog niet zijn wat ze moeten zijn.

**Screenshot(s):**

-screenshot(s) van je eindresultaat-



## Voortgang 3 (week 6)

## Stand van zaken

Ik ben begonnen aan de tweede pagina maar dit lukt nog niet helemaal zoals ik wil en ik overweeg daarom een andere pagina van de awakenings website na te maken.
Het hamburgermenu werkt nu maar is nog niet helemaal perfect.
Ook lukt het nog niet echt met mediaqueries.

**Screenshot(s):**

Ik kon op dit moment helaas geen screenshots maken i.v.m. problemen met mijn laptop.

## Agenda voor meeting

- Toelichting mediaqueries.
- Wat te doen als je op de responsive plane gaat focussen?


## Voortgang 2 (week 5)

## Stand van zaken

Ik ben bezig de menubalk boven in de pagina te veranderen in een hamburger menu. Ik weet alleen nog niet hoe ik dat ga doen, of dat met css of met javascript het handigst is.

**Screenshot(s):**

Ik kon op dit moment helaas geen screenshots maken i.v.m. problemen met mijn laptop.

## Agenda voor de meeting

- Meer toelichting over ontzichtbare headings.
- JS carrousel toelichting.



## Voortgang 1 (week 3)

### Stand van zaken

Flexbox was nog even lastig maar is uiteindelijk wel gelukt.
Menubalk boven in en in de footer zijn daardoor nu responsive, maar de menubalk bovenin moet een hamburgermenu worden.

**Screenshot(s):**

Ik kon op dit moment helaas geen screenshots maken i.v.m. problemen met mijn laptop.

### Agenda voor meeting

- Dingen naast elkaar zetten voor mobiel en voor overgang naar desktop.
- Mag je classes gebruiken?
- Moet je hamburgermenu werken?
- Hoe maak je een hamburger menu?
- Flexbox vragen.

### Verslag van meeting

-na afloop snel uitkomsten vastleggen-



## Intake (week 1)

**Je startniveau:** blauw

**Je focus:** responsive

**Je opdracht:** Awakenings website

**Screenshot(s):**

![screenshot(s) die een goed beeld geven van de website die je gaat maken]
(images/screenshot1) (images/screenshot2) (images/screenshot3)

**Breakdown-schets(en):**


